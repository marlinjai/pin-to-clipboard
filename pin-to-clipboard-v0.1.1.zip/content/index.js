// src/content/pin-detection.ts
function findPinCards(root) {
  return Array.from(
    root.querySelectorAll(
      '[data-test-id="pin"], [data-test-id="pin-closeup"]'
    )
  );
}
function classifyCard(card) {
  if (card.querySelector('[data-test-id="video-duration"], video')) return "video";
  return "image";
}
function pickLargestSrcset(img) {
  const srcset = img.getAttribute("srcset");
  if (!srcset) return null;
  const entries = srcset.split(",").map((s) => s.trim());
  let best = null;
  for (const e of entries) {
    const [url, w] = e.split(/\s+/);
    if (!url) continue;
    const weight = parseFloat((w ?? "1x").replace(/[^\d.]/g, "")) || 1;
    if (!best || weight > best.weight) best = { url, weight };
  }
  return best?.url ?? null;
}
function extractCandidateImageUrl(card) {
  const img = card.querySelector("img");
  if (!img) return null;
  const fromSrcset = pickLargestSrcset(img);
  const candidate = fromSrcset ?? img.currentSrc ?? img.src;
  if (!candidate || candidate.startsWith("data:")) return null;
  if (!/i\.pinimg\.com/.test(candidate)) return null;
  if (img.naturalWidth > 0 && img.naturalWidth < 100) return null;
  return candidate;
}
function extractVideoSources(card) {
  const video = card.querySelector("video");
  const posterUrl = video?.poster || card.querySelector("img")?.src;
  let mp4Url;
  let hlsUrl;
  card.querySelectorAll("video source").forEach((s) => {
    if (s.type?.includes("mp4") || /\.mp4(\?|$)/.test(s.src)) mp4Url = s.src;
    if (s.type?.includes("mpegURL") || /\.m3u8(\?|$)/.test(s.src)) hlsUrl = s.src;
  });
  return { mp4Url, hlsUrl, posterUrl };
}

// src/content/hover-button.ts
var ATTR = "data-ptc-bound";
var STYLE_ID = "ptc-style";
var ICONS = {
  copy: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
  loading: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke-opacity="0.3"/><path d="M21 12a9 9 0 0 0-9-9"/></svg>`,
  ok: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>`,
  error: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>`
};
function ensureStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const s = document.createElement("style");
  s.id = STYLE_ID;
  s.textContent = `
    [data-ptc-host]{position:relative;}
    button[data-ptc="copy"]{
      position:absolute;left:10px;bottom:10px;
      width:40px;height:40px;border-radius:50%;
      border:0;padding:0;cursor:pointer;
      background:#E60023;color:#fff;
      box-shadow:0 2px 8px rgba(0,0,0,.18);
      opacity:0;transform:translateY(4px);
      transition:opacity .12s ease,transform .12s ease,background .12s ease;
      display:grid;place-items:center;
      z-index:2147483600;
      font:14px/1 -apple-system,system-ui,sans-serif;
    }
    [data-ptc-host]:hover button[data-ptc="copy"],
    button[data-ptc="copy"]:focus-visible,
    button[data-ptc="copy"][data-state="loading"],
    button[data-ptc="copy"][data-state="ok"],
    button[data-ptc="copy"][data-state="error"]{
      opacity:1;transform:translateY(0);
    }
    button[data-ptc="copy"]:hover{background:#AD081B;}
    button[data-ptc="copy"]:focus-visible{outline:2px solid #fff;outline-offset:2px;}
    button[data-ptc="copy"][data-state="ok"]{background:#AD081B;}
    button[data-ptc="copy"][data-state="error"]{background:#444;}
    button[data-ptc="copy"] [data-icon]{display:none;line-height:0;}
    button[data-ptc="copy"][data-state="idle"] [data-icon="copy"],
    button[data-ptc="copy"][data-state="loading"] [data-icon="loading"],
    button[data-ptc="copy"][data-state="ok"] [data-icon="ok"],
    button[data-ptc="copy"][data-state="error"] [data-icon="error"]{display:block;}
    button[data-ptc="copy"][data-state="loading"] [data-icon="loading"]{
      animation:ptc-spin .8s linear infinite;transform-origin:50% 50%;
    }
    @keyframes ptc-spin{to{transform:rotate(360deg);}}
  `;
  document.head.appendChild(s);
}
function buildIconHosts() {
  return `<span data-icon="copy">${ICONS.copy}</span><span data-icon="loading">${ICONS.loading}</span><span data-icon="ok">${ICONS.ok}</span><span data-icon="error">${ICONS.error}</span>`;
}
function attachHoverButton(card, onClick) {
  ensureStyle();
  if (card.getAttribute(ATTR)) {
    const existing = card.querySelector('button[data-ptc="copy"]');
    return { setState: (s) => existing.dataset.state = s };
  }
  card.setAttribute(ATTR, "1");
  card.setAttribute("data-ptc-host", "1");
  const btn = document.createElement("button");
  btn.type = "button";
  btn.dataset.ptc = "copy";
  btn.dataset.state = "idle";
  btn.setAttribute("aria-label", "Copy image to clipboard");
  btn.innerHTML = buildIconHosts();
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    onClick(card);
  });
  card.appendChild(btn);
  return {
    setState: (s) => {
      btn.dataset.state = s;
    }
  };
}

// src/shared/base64.ts
function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

// src/content/clipboard.ts
async function send(msg) {
  const r = await chrome.runtime.sendMessage(msg);
  if (!r) throw new Error("service worker returned no response");
  return r;
}
async function transcodeToPng(source) {
  const bitmap = await createImageBitmap(source);
  try {
    const canvas = document.createElement("canvas");
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("could not get a 2d canvas context");
    ctx.drawImage(bitmap, 0, 0);
    return await new Promise(
      (resolve, reject) => canvas.toBlob(
        (b) => b ? resolve(b) : reject(new Error("canvas.toBlob returned null")),
        "image/png"
      )
    );
  } finally {
    bitmap.close();
  }
}
async function buildPngBlob(args) {
  const r = await send({ type: "COPY_IMAGE", ...args });
  if (!r.ok) {
    throw Object.assign(new Error(r.message), {
      fallbackUrl: r.fallbackUrl ?? args.candidateUrl
    });
  }
  if (r.type !== "IMAGE") {
    throw Object.assign(new Error("unexpected response"), {
      fallbackUrl: args.candidateUrl
    });
  }
  const sourceBlob = new Blob([base64ToBytes(r.base64)], {
    type: r.mimeType
  });
  if (r.mimeType === "image/png") return sourceBlob;
  try {
    return await transcodeToPng(sourceBlob);
  } catch (e) {
    throw Object.assign(new Error(`transcode failed: ${e.message}`), {
      fallbackUrl: args.candidateUrl
    });
  }
}
async function copyImage(args) {
  const blobPromise = buildPngBlob(args);
  blobPromise.catch(() => {
  });
  try {
    const item = new ClipboardItem({ "image/png": blobPromise });
    await navigator.clipboard.write([item]);
    return { ok: true };
  } catch (e) {
    let err = e;
    try {
      await blobPromise;
    } catch (inner) {
      err = inner;
    }
    const fallbackUrl = err.fallbackUrl ?? args.candidateUrl;
    try {
      await navigator.clipboard.writeText(fallbackUrl);
      return { ok: true, fellBackToUrl: true, errorMessage: err.message };
    } catch {
      return { ok: false, errorMessage: err.message };
    }
  }
}

// src/content/toast.ts
function showToast(message, kind = "info", durationMs = 1800) {
  const existing = document.querySelector("[data-ptc-toast]");
  if (existing) existing.remove();
  const el = document.createElement("div");
  el.setAttribute("data-ptc-toast", kind);
  el.setAttribute("role", kind === "error" ? "alert" : "status");
  el.textContent = message;
  Object.assign(el.style, {
    position: "fixed",
    bottom: "24px",
    left: "50%",
    transform: "translateX(-50%)",
    background: "#111",
    color: "#fff",
    padding: "10px 16px",
    borderRadius: "10px",
    boxShadow: "0 6px 20px rgba(0,0,0,.25)",
    font: "14px/1.3 -apple-system, system-ui, sans-serif",
    zIndex: "2147483647",
    pointerEvents: "none",
    maxWidth: "min(560px, calc(100vw - 32px))"
  });
  document.body.appendChild(el);
  setTimeout(() => el.remove(), durationMs);
}

// src/shared/types.ts
var DEFAULT_SETTINGS = {
  imageQuality: "largest-available",
  videoAction: "copy-url"
};

// src/options/storage.ts
var IMAGE_QUALITIES = ["largest-available", "original"];
var VIDEO_ACTIONS = ["copy-url", "download", "both"];
function sanitize(raw) {
  const r = raw ?? {};
  return {
    imageQuality: IMAGE_QUALITIES.includes(r.imageQuality) ? r.imageQuality : DEFAULT_SETTINGS.imageQuality,
    videoAction: VIDEO_ACTIONS.includes(r.videoAction) ? r.videoAction : DEFAULT_SETTINGS.videoAction
  };
}
async function getSettings() {
  const { settings } = await chrome.storage.sync.get("settings");
  return sanitize(settings);
}

// src/content/index.ts
var scheduled = false;
function scheduleScan(root = document) {
  if (scheduled) return;
  scheduled = true;
  setTimeout(() => {
    scheduled = false;
    scan(root);
  }, 150);
}
function pinIdFromCard(card) {
  return card.dataset.pinId ?? card.querySelector("a[href*='/pin/']")?.href.match(/\/pin\/(\d+)/)?.[1] ?? Math.random().toString(36).slice(2);
}
function isContextInvalidated(e) {
  return /Extension context invalidated/i.test(String(e?.message ?? ""));
}
async function handleClick(card, setState) {
  try {
    const settings = await getSettings();
    const kind = classifyCard(card);
    const pinId = pinIdFromCard(card);
    setState("loading");
    if (kind === "video" && document.querySelector("[data-test-id=pin-closeup]") === card) {
      const sources = extractVideoSources(card);
      const r2 = await chrome.runtime.sendMessage({ type: "VIDEO_ACTION", pinId, sources });
      if (r2?.ok && r2.type === "VIDEO_DONE") {
        if (r2.copiedUrl) await navigator.clipboard.writeText(r2.copiedUrl);
        setState("ok");
        showToast(r2.downloaded ? "Video downloaded, URL copied" : "Video URL copied", "ok");
        return;
      }
      setState("error");
      showToast("No video source found", "error");
      return;
    }
    const candidate = kind === "video" ? extractVideoSources(card).posterUrl ?? null : extractCandidateImageUrl(card);
    if (!candidate) {
      setState("error");
      showToast("Image not ready yet, try again", "error");
      return;
    }
    const r = await copyImage({ pinId, candidateUrl: candidate, quality: settings.imageQuality });
    if (r.ok) {
      setState("ok");
      showToast(
        r.fellBackToUrl ? "Couldn't copy image, copied URL instead" : "Image copied",
        r.fellBackToUrl ? "info" : "ok"
      );
    } else {
      setState("error");
      showToast(r.errorMessage ?? "Copy failed", "error");
    }
  } catch (e) {
    setState("error");
    if (isContextInvalidated(e)) {
      showToast("Please reload this page (extension was updated)", "error");
    } else {
      showToast("Copy failed", "error");
    }
  }
}
function scan(root) {
  for (const card of findPinCards(root)) {
    const api = attachHoverButton(
      card,
      (c) => handleClick(c, api.setState)
    );
  }
}
function hookRouteChanges() {
  const fire = () => scheduleScan(document);
  for (const m of ["pushState", "replaceState"]) {
    const orig = history[m];
    history[m] = function(...args) {
      const r = orig.apply(this, args);
      fire();
      return r;
    };
  }
  window.addEventListener("popstate", fire);
}
function start() {
  scan(document);
  new MutationObserver(() => scheduleScan(document)).observe(document.body, {
    childList: true,
    subtree: true
  });
  hookRouteChanges();
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", start);
} else {
  start();
}
//# sourceMappingURL=index.js.map
