// src/background/resolver.ts
var LADDER_LARGEST = ["originals", "1200x", "736x", "564x", "474x"];
var SIZE_RE = /\/(60x60|75x75_RS|170x|236x|474x|564x|736x|1200x|originals)\//;
var EXT_RE = /\.(jpg|jpeg|png|webp|gif)$/i;
var EXT_PERMS = ["jpg", "png", "webp", "gif"];
var MAX_PROBES = 6;
var cache = /* @__PURE__ */ new Map();
var inflight = /* @__PURE__ */ new Map();
function candidatesFor(displayed, quality) {
  const sizeMatch = displayed.match(SIZE_RE);
  const extMatch = displayed.match(EXT_RE);
  if (!sizeMatch || !extMatch) return [displayed];
  const currentExt = extMatch[1].toLowerCase();
  const orderedExts = [currentExt, ...EXT_PERMS.filter((e) => e !== currentExt)];
  const ladder = quality === "original" ? LADDER_LARGEST : LADDER_LARGEST.slice(1);
  const out = [];
  for (const size of ladder) {
    for (const ext of orderedExts) {
      const u = displayed.replace(SIZE_RE, `/${size}/`).replace(EXT_RE, `.${ext}`);
      if (u !== displayed) out.push(u);
      if (size !== "originals") break;
    }
  }
  return out;
}
async function probe(url) {
  try {
    const res = await fetch(url, { method: "HEAD" });
    return res.status;
  } catch {
    return 0;
  }
}
async function resolveBestUrl(pinId, displayed, quality) {
  const cached = cache.get(pinId);
  if (cached) return cached;
  const pending = inflight.get(pinId);
  if (pending) return pending;
  const task = (async () => {
    const candidates = candidatesFor(displayed, quality).slice(0, MAX_PROBES);
    let backoff = false;
    for (const u of candidates) {
      const s = await probe(u);
      if (s === 200) {
        const r = { url: u, backoff };
        cache.set(pinId, r);
        return r;
      }
      if (s === 429 || s === 403) backoff = true;
    }
    const fallback = { url: displayed, backoff };
    cache.set(pinId, fallback);
    return fallback;
  })();
  inflight.set(pinId, task);
  try {
    return await task;
  } finally {
    inflight.delete(pinId);
  }
}

// src/background/fetcher.ts
async function fetchBytes(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`fetch ${url} -> ${res.status}`);
  const mimeType = res.headers.get("content-type")?.split(";")[0]?.trim() || "application/octet-stream";
  const bytes = await res.arrayBuffer();
  return { bytes, mimeType };
}

// src/shared/base64.ts
var CHUNK = 32768;
function bytesToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}

// src/background/index.ts
function fail(code, message, fallbackUrl) {
  return { ok: false, code, message, fallbackUrl };
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "COPY_IMAGE") {
        const resolved = await resolveBestUrl(msg.pinId, msg.candidateUrl, msg.quality);
        if (resolved.backoff && resolved.url === msg.candidateUrl) {
          return fail("CDN_BLOCKED", "CDN throttled, using displayed size", resolved.url);
        }
        try {
          const { bytes, mimeType } = await fetchBytes(resolved.url);
          if (mimeType === "image/gif" || mimeType === "image/apng") {
            return fail("ANIMATED_UNCOPYABLE", "Animated image, copy URL instead", resolved.url);
          }
          return {
            ok: true,
            type: "IMAGE",
            base64: bytesToBase64(bytes),
            mimeType,
            resolvedUrl: resolved.url
          };
        } catch (e) {
          return fail("FETCH_FAILED", String(e.message), resolved.url);
        }
      }
      if (msg.type === "VIDEO_ACTION") {
        const { mp4Url, hlsUrl } = msg.sources;
        const settings = (await chrome.storage.sync.get("settings")).settings ?? {};
        const action = settings.videoAction ?? "copy-url";
        const url = mp4Url ?? hlsUrl;
        if (!url) return fail("NO_VIDEO_SOURCE", "No video source on page");
        let downloaded = false;
        if ((action === "download" || action === "both") && mp4Url) {
          await chrome.downloads.download({ url: mp4Url });
          downloaded = true;
        }
        return { ok: true, type: "VIDEO_DONE", copiedUrl: url, downloaded };
      }
      return fail("FETCH_FAILED", "Unknown message");
    } catch (e) {
      return fail("FETCH_FAILED", String(e.message));
    }
  })().then(sendResponse);
  return true;
});
chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});
//# sourceMappingURL=index.js.map
