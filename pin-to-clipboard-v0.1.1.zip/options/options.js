// src/shared/types.ts
var DEFAULT_SETTINGS = {
  imageQuality: "largest-available",
  videoAction: "copy-url"
};

// src/options/storage.ts
var IMAGE_QUALITIES = ["largest-available", "original"];
var VIDEO_ACTIONS = ["copy-url", "download", "both"];
function sanitize(raw) {
  const r = raw ?? {};
  return {
    imageQuality: IMAGE_QUALITIES.includes(r.imageQuality) ? r.imageQuality : DEFAULT_SETTINGS.imageQuality,
    videoAction: VIDEO_ACTIONS.includes(r.videoAction) ? r.videoAction : DEFAULT_SETTINGS.videoAction
  };
}
async function getSettings() {
  const { settings } = await chrome.storage.sync.get("settings");
  return sanitize(settings);
}
async function setSettings(patch) {
  const current = await getSettings();
  await chrome.storage.sync.set({ settings: { ...current, ...patch } });
}

// src/options/options.ts
async function hydrate() {
  const s = await getSettings();
  for (const [name, value] of Object.entries(s)) {
    const el = document.querySelector(
      `input[name="${name}"][value="${value}"]`
    );
    if (el) el.checked = true;
  }
}
function wire() {
  document.querySelectorAll("input[type=radio]").forEach((el) => {
    el.addEventListener("change", () => {
      if (!el.checked) return;
      setSettings({ [el.name]: el.value });
    });
  });
}
hydrate().then(wire);
//# sourceMappingURL=options.js.map
